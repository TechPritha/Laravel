<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Testc;

Route::get("/ggi",[Testc::class,"abcfun"]);
Route::get("/",[Testc::class,"home"]);

// Route::get('/', function () {
//     return view('welcome');
// });
