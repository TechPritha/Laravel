<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Testc extends Controller
{
    public function abcfun(){
        // echo "I am laravel developer";

        $n="Pritha";
        $e="p@gmail.com";

        $w=array(
            "name"=>$n,
            "email"=>$e


        );
        return view("myggi")->with($w);
    }

    public function home(){
        echo "I am home";
    }
}
